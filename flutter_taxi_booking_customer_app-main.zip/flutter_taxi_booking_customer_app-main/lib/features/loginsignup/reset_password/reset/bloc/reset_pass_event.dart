import 'package:equatable/equatable.dart';

abstract class ResetPassEvent extends Equatable {
  const ResetPassEvent();
}
