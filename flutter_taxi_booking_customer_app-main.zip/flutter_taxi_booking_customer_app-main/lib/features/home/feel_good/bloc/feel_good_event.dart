import 'package:equatable/equatable.dart';

abstract class FeelGoodEvent extends Equatable {
  const FeelGoodEvent();
}
