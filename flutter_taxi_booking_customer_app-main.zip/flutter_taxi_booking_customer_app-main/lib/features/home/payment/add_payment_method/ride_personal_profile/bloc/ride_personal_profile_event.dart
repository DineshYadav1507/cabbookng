import 'package:equatable/equatable.dart';

abstract class RidePersonalProfileEvent extends Equatable {
  const RidePersonalProfileEvent();
}
