import 'package:equatable/equatable.dart';

abstract class AddApplePayEvent extends Equatable {
  const AddApplePayEvent();
}
