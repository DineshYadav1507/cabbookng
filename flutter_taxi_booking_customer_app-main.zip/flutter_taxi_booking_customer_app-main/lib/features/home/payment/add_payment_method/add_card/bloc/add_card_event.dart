import 'package:equatable/equatable.dart';

abstract class AddCardEvent extends Equatable {
  const AddCardEvent();
}
