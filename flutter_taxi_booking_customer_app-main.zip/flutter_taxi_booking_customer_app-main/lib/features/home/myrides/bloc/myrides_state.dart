import 'package:equatable/equatable.dart';

abstract class MyridesState extends Equatable {
  const MyridesState();
}

class InitialMyridesState extends MyridesState {
  @override
  List<Object> get props => [];
}
