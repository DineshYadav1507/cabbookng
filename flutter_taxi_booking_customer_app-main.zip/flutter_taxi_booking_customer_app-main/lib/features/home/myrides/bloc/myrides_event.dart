import 'package:equatable/equatable.dart';

abstract class MyridesEvent extends Equatable {
  const MyridesEvent();
}
