import 'package:equatable/equatable.dart';

abstract class FreeRidesEvent extends Equatable {
  const FreeRidesEvent();
}
