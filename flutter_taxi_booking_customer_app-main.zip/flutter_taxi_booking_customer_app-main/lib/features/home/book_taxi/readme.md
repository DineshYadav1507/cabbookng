This package has the taxi booking flow. I seprated into 3 sections.

1. Location information
2. Vehicle information
3. Ongoing trips


1. Location information
    This package handle all the getting location related things like adding faviorite location, 
selecting pickup-dropoff location, etc. Inshort package has to get the From-To location details.

2. Vehicle information
    Once "Location information" package confirm the From-To location then only this package comes in role.
Using the location points this package shows available nearby taxis, his fare amount, distance and option to change
vehicle type.If user confirm all the details then we send all the drivers to accept the job.

3.Ongoing trips
    This is live tracking page where driver and customer both can see the ongoing trip.     
