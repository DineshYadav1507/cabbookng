import 'package:equatable/equatable.dart';

abstract class WhereToEvent extends Equatable {
  const WhereToEvent();
}
