import 'package:equatable/equatable.dart';

abstract class AddAddressToMylistState extends Equatable {
  const AddAddressToMylistState();
}

class InitialAddAddressToMylistState extends AddAddressToMylistState {
  @override
  List<Object> get props => [];
}
