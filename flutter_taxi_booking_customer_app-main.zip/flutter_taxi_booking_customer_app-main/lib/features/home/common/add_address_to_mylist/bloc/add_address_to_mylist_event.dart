import 'package:equatable/equatable.dart';

abstract class AddAddressToMylistEvent extends Equatable {
  const AddAddressToMylistEvent();
}
