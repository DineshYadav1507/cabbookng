import 'package:equatable/equatable.dart';

abstract class LocationFromMapEvent extends Equatable {
  const LocationFromMapEvent();
}
