import 'package:equatable/equatable.dart';

abstract class HelpSupportState extends Equatable {
  const HelpSupportState();
}

class InitialHelpSupportState extends HelpSupportState {
  @override
  List<Object> get props => [];
}
