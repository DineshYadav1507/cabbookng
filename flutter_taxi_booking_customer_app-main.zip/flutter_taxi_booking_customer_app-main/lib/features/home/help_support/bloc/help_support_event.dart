import 'package:equatable/equatable.dart';

abstract class HelpSupportEvent extends Equatable {
  const HelpSupportEvent();
}
