import 'package:equatable/equatable.dart';

abstract class HelpSupportQuestionsState extends Equatable {
  const HelpSupportQuestionsState();
}

class InitialHelpSupportQuestionsState extends HelpSupportQuestionsState {
  @override
  List<Object> get props => [];
}
