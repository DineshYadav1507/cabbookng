import 'package:equatable/equatable.dart';

abstract class HelpSupportQuestionsEvent extends Equatable {
  const HelpSupportQuestionsEvent();
}
