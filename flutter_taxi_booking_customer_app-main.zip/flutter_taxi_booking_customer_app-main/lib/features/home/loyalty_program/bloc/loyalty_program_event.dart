import 'package:equatable/equatable.dart';

abstract class LoyaltyProgramEvent extends Equatable {
  const LoyaltyProgramEvent();
}
