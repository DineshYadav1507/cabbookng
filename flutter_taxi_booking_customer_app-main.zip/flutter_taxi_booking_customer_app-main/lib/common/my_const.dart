const String kAppName = "Viit Customer";
const String kAPIBaseURL = "http://api.xlcabking.softclutch.com/api";

const String kLoremText =
    "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s when an unknown printer took a galley.";
