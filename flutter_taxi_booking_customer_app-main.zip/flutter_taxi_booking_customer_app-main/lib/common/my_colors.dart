import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFF275787);
const kAccentColor = Color(0xFFFFAA00);
const Color kBlack = Color(0xFF030303);
const Color kLoginBlack = Color(0xFF060518);
const Color kSocialBg = Color(0xFFF7F3F3);
const Color kTextLoginfaceid = Color(0xFF8F92A1);
const Color kDottedBorder = Color(0xFFA1A0A6);
const Color kDottedBorderFab = Color(0xFFB0AFB6);
const Color kNavItemSelected = Color(0xFFEEEEEE);
const Color kSettingTopBg = Color(0xFFF3F3F3);
const Color kSettingFavAddAvtarBg = Color(0xFFEDEBEB);
const Color kDanger = Color(0xFFDF2E21);
const Color kGrey = Color(0xFFE8E4E4);
const Color kShareCodeBg = Color(0xFFF1F3F7);
const Color kSettingDivider = Color(0xFFF1F1F1);
const String kLoremText =
    "Lorem Ipsum is simply dummy text of the printing and typesetting. ";
const Color kGreen = Color(0xFF28B446);