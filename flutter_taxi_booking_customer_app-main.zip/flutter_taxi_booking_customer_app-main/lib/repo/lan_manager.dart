class LanManager {
  static const KEY_LBL_LOGIN = "lbl_login";
}
