package com.example.flutter_taxi_booking_customer_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
